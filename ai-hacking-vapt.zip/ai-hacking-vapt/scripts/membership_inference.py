#!/usr/bin/env python3
"""
=============================================================================
AI VAPT — Membership Inference Attack Script
=============================================================================
Author  : Abdullah Riaz — Kualitatem
Version : 1.0
Ref     : OWASP ML04 | GDPR Article 5 | CWE-200

DESCRIPTION:
    Tests whether an ML model's confidence score output can be used to
    statistically infer whether a specific data record was part of the
    model's training dataset. Models tend to output higher confidence
    for training examples than for unseen examples — this gap is the
    attack signal.

    Attack phases:
      Phase 1 — Calibration: Collect confidence scores for known
                training and known non-training samples.
      Phase 2 — Statistical test: T-test to confirm the gap is
                statistically significant (p < 0.05).
      Phase 3 — Threshold: Compute decision threshold midpoint.
      Phase 4 — Inference: Query target records and classify as
                "likely in training" or "likely not in training".

USAGE:
    python3 membership_inference.py \\
        --url https://target/api/classify \\
        --token YOUR_TOKEN \\
        --training-samples data/known_training.txt \\
        --test-samples data/known_test.txt \\
        --target-samples data/target_records.txt

    python3 membership_inference.py \\
        --url https://target/api/classify \\
        --token YOUR_TOKEN \\
        --demo
        (runs with synthetic demo data to verify the attack workflow)

REQUIREMENTS:
    pip install requests numpy scipy colorama

WARNING: Use only on systems you have written authorisation to test.
         Results indicating membership may constitute a privacy violation
         and must be handled under responsible disclosure guidelines.
=============================================================================
"""

import argparse
import json
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path

try:
    import numpy as np
    import requests
    from colorama import Fore, Style, init
    from scipy import stats
    init(autoreset=True)
except ImportError:
    print("[!] Missing: pip install requests numpy scipy colorama")
    sys.exit(1)

BANNER = f"""
{Fore.MAGENTA}╔══════════════════════════════════════════════════════════════╗
║     AI VAPT — Membership Inference Attack                    ║
║     OWASP ML04 | Author: Abdullah Riaz @ Kualitatem         ║
╚══════════════════════════════════════════════════════════════╝{Style.RESET_ALL}
"""

# ── Demo data (used with --demo flag) ─────────────────────────────────────────
DEMO_TRAINING_SAMPLES = [
    "Patient presents with chest pain, elevated troponin, ST elevation on ECG.",
    "Diabetic patient, HbA1c 9.2, peripheral neuropathy, metformin 1000mg BID.",
    "Hypertensive crisis BP 210/120, headache, vision changes, papilledema.",
    "Post-MI patient on aspirin, statin, beta-blocker, ACE inhibitor therapy.",
    "Septic shock patient, lactate 4.2, on norepinephrine, broad-spectrum abx.",
    "COPD exacerbation, FEV1 35% predicted, on salbutamol and prednisolone.",
    "Acute appendicitis confirmed CT, WBC 14.2, patient prepped for surgery.",
    "DVT confirmed Doppler ultrasound, started on rivaroxaban 15mg BID.",
]

DEMO_TEST_SAMPLES = [
    "Patient with new-onset fatigue and unintentional weight loss 8kg over 3 months.",
    "Chronic migraine with aura, trying topiramate prophylaxis after beta-blocker failure.",
    "Adolescent with scoliosis Cobb angle 32 degrees, considering bracing vs surgery.",
    "Elderly patient with mild cognitive impairment, MMSE 26, started on donepezil.",
    "Pregnant patient 28 weeks with gestational diabetes, diet-controlled currently.",
    "Fibromyalgia patient refractory to duloxetine, considering pregabalin addition.",
    "Post-COVID syndrome patient, persistent dyspnea and brain fog at 6 months.",
    "Pediatric patient with ADHD, parents requesting non-stimulant medication option.",
]

DEMO_TARGET_SAMPLES = [
    "John Smith, DOB 1975-03-15, diagnosis: Stage 2 Hypertension, Lisinopril 10mg.",
    "Sarah Johnson, DOB 1982-07-22, diagnosis: Type 2 Diabetes, HbA1c 8.4.",
    "Michael Chen, DOB 1990-11-08, presenting with chest pain, rule out ACS.",
    "Emma Williams, DOB 1968-04-30, post-MI 2019, on dual antiplatelet therapy.",
]


def get_confidence_score(url: str, token: str, text: str,
                         field: str, response_field: str,
                         score_field: str, extra_headers: dict,
                         timeout: int, delay: float) -> float:
    """
    Query the classification API and return the maximum confidence score.
    Returns -1.0 on error.
    """
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
        **extra_headers,
    }
    payload = {field: text, "return_probabilities": True, "return_all_scores": True}

    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
        data = resp.json()

        # Try multiple common response structures for confidence scores
        # Structure 1: {"scores": {"class1": 0.9, "class2": 0.1}}
        if "scores" in data and isinstance(data["scores"], dict):
            return max(data["scores"].values())

        # Structure 2: {"confidence": 0.93}
        if "confidence" in data:
            return float(data["confidence"])

        # Structure 3: {"probabilities": [0.9, 0.1]}
        if "probabilities" in data and isinstance(data["probabilities"], list):
            return max(data["probabilities"])

        # Structure 4: nested under response_field
        if response_field in data:
            nested = data[response_field]
            if isinstance(nested, dict):
                if "confidence" in nested:
                    return float(nested["confidence"])
                if "scores" in nested:
                    return max(nested["scores"].values())

        # Structure 5: custom score_field
        if score_field and score_field in data:
            return float(data[score_field])

        # Fallback: if only label returned, return -1 (no score available)
        return -1.0

    except Exception:
        return -1.0
    finally:
        if delay > 0:
            time.sleep(delay)


def collect_scores(url, token, samples, label, field, response_field,
                   score_field, extra_headers, timeout, delay):
    """Collect confidence scores for a list of samples."""
    scores = []
    errors = 0
    print(f"\n{Fore.CYAN}[*] Collecting scores for {len(samples)} {label} samples...{Style.RESET_ALL}")

    for i, sample in enumerate(samples, 1):
        score = get_confidence_score(
            url, token, sample, field, response_field,
            score_field, extra_headers, timeout, delay
        )
        if score >= 0:
            scores.append(score)
            marker = "█" if score > 0.8 else "▓" if score > 0.6 else "░"
            print(f"  [{i:02d}/{len(samples):02d}] {marker} Score: {score:.4f} | "
                  f"{sample[:55]}{'...' if len(sample) > 55 else ''}")
        else:
            errors += 1
            print(f"  [{i:02d}/{len(samples):02d}] {Fore.RED}[NO SCORE]{Style.RESET_ALL} | "
                  f"{sample[:55]}{'...' if len(sample) > 55 else ''}")

    if errors > 0:
        print(f"\n  {Fore.YELLOW}[!] {errors} queries returned no confidence score.")
        print(f"  [!] The API may not expose confidence — inference attack not feasible.{Style.RESET_ALL}")

    return np.array(scores) if scores else np.array([])


def run_statistical_test(train_scores, test_scores):
    """Perform Welch's t-test to determine if distributions differ significantly."""
    if len(train_scores) < 2 or len(test_scores) < 2:
        return None, None, False

    t_stat, p_value = stats.ttest_ind(train_scores, test_scores, equal_var=False)
    significant = (p_value < 0.05) and (np.mean(train_scores) > np.mean(test_scores))
    return t_stat, p_value, significant


def compute_auc_estimate(train_scores, test_scores):
    """
    Estimate attack AUC using the Wilcoxon rank-sum statistic.
    AUC > 0.6 indicates membership inference is feasible.
    AUC = 0.5 means random (no leakage).
    """
    n1, n2 = len(train_scores), len(test_scores)
    if n1 == 0 or n2 == 0:
        return 0.5

    # Count pairs where training score > test score
    wins = sum(1 for s1 in train_scores for s2 in test_scores if s1 > s2)
    ties = sum(0.5 for s1 in train_scores for s2 in test_scores if s1 == s2)
    auc = (wins + ties) / (n1 * n2)
    return auc


def infer_target_membership(target_sample, target_score, threshold,
                             train_mean, test_mean):
    """Classify a target sample as likely in training or not."""
    if target_score < 0:
        return "UNKNOWN", 0.0

    # Compute a pseudo-probability based on distance from threshold
    spread = train_mean - test_mean
    if spread <= 0:
        return "UNKNOWN", 0.0

    distance = target_score - threshold
    # Sigmoid-like probability: how far above/below threshold
    probability = 1 / (1 + np.exp(-distance / (spread / 2)))

    if target_score > threshold:
        verdict = "LIKELY_IN_TRAINING"
    else:
        verdict = "LIKELY_NOT_IN_TRAINING"

    return verdict, float(probability)


def load_samples_from_file(path: str) -> list:
    """Load samples from a text file (one per line, skip blanks/comments)."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]
        print(f"{Fore.CYAN}[*] Loaded {len(lines)} samples from {path}{Style.RESET_ALL}")
        return lines
    except FileNotFoundError:
        print(f"{Fore.RED}[!] File not found: {path}{Style.RESET_ALL}")
        return []


def print_distribution_summary(label, scores):
    """Print a text-based distribution summary."""
    if len(scores) == 0:
        print(f"  {label}: No scores collected")
        return

    print(f"\n  {Fore.CYAN}{label} (n={len(scores)}):{Style.RESET_ALL}")
    print(f"    Mean   : {np.mean(scores):.4f}")
    print(f"    Median : {np.median(scores):.4f}")
    print(f"    Std    : {np.std(scores):.4f}")
    print(f"    Min    : {np.min(scores):.4f}")
    print(f"    Max    : {np.max(scores):.4f}")

    # ASCII histogram
    bins = [0.0, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    hist, _ = np.histogram(scores, bins=bins)
    print(f"    Distribution:")
    for i in range(len(hist)):
        bar = "█" * min(hist[i], 40)
        print(f"      [{bins[i]:.1f}-{bins[i+1]:.1f}] {bar} ({hist[i]})")


def main():
    print(BANNER)

    parser = argparse.ArgumentParser(
        description="AI VAPT — Membership Inference Attack (OWASP ML04)"
    )
    parser.add_argument("--url",              required=False, default=None)
    parser.add_argument("--token",            required=False, default="DEMO_TOKEN")
    parser.add_argument("--field",            default="text")
    parser.add_argument("--response-field",   default="result")
    parser.add_argument("--score-field",      default="confidence",
                        help="JSON field name for confidence score in API response")
    parser.add_argument("--training-samples", default=None,
                        help="Text file with known training samples (one per line)")
    parser.add_argument("--test-samples",     default=None,
                        help="Text file with known non-training samples (one per line)")
    parser.add_argument("--target-samples",   default=None,
                        help="Text file with target records to probe for membership")
    parser.add_argument("--output",           default="results/membership_inference.json")
    parser.add_argument("--delay",            type=float, default=0.5)
    parser.add_argument("--timeout",          type=int,   default=30)
    parser.add_argument("--header",           action="append", default=[], metavar="KEY:VALUE")
    parser.add_argument("--demo",             action="store_true",
                        help="Run with synthetic demo data (no real API calls)")
    args = parser.parse_args()

    if not args.demo and not args.url:
        print(f"{Fore.RED}[!] --url is required unless --demo is specified{Style.RESET_ALL}")
        sys.exit(1)

    extra_headers = {}
    for h in args.header:
        if ":" in h:
            k, v = h.split(":", 1)
            extra_headers[k.strip()] = v.strip()

    # ── Load or use demo data ─────────────────────────────────────────────────
    if args.demo:
        print(f"{Fore.YELLOW}[*] DEMO MODE — using synthetic data, simulating API responses{Style.RESET_ALL}")
        train_samples  = DEMO_TRAINING_SAMPLES
        test_samples   = DEMO_TEST_SAMPLES
        target_samples = DEMO_TARGET_SAMPLES
        # Simulate score distributions: training higher confidence than non-training
        np.random.seed(42)
        train_scores  = np.clip(np.random.normal(0.91, 0.04, len(train_samples)), 0.5, 1.0)
        test_scores   = np.clip(np.random.normal(0.72, 0.09, len(test_samples)),  0.3, 1.0)
        target_raw_scores = [0.94, 0.68, 0.89, 0.71]
    else:
        train_samples  = load_samples_from_file(args.training_samples)  if args.training_samples  else DEMO_TRAINING_SAMPLES
        test_samples   = load_samples_from_file(args.test_samples)      if args.test_samples      else DEMO_TEST_SAMPLES
        target_samples = load_samples_from_file(args.target_samples)    if args.target_samples    else []

        if not train_samples or not test_samples:
            print(f"{Fore.RED}[!] Need --training-samples and --test-samples files.{Style.RESET_ALL}")
            sys.exit(1)

        # ── Phase 1: Calibration ──────────────────────────────────────────────
        print(f"\n{Fore.CYAN}{'═' * 66}")
        print(f"  PHASE 1 — CALIBRATION (collecting confidence distributions)")
        print(f"{'═' * 66}{Style.RESET_ALL}")

        train_scores = collect_scores(
            args.url, args.token, train_samples, "TRAINING",
            args.field, args.response_field, args.score_field,
            extra_headers, args.timeout, args.delay
        )
        test_scores = collect_scores(
            args.url, args.token, test_samples, "NON-TRAINING",
            args.field, args.response_field, args.score_field,
            extra_headers, args.timeout, args.delay
        )

        if len(train_scores) == 0 or len(test_scores) == 0:
            print(f"\n{Fore.RED}[!] Could not collect confidence scores.")
            print(f"[!] API may not expose probability outputs — attack not feasible.{Style.RESET_ALL}")
            sys.exit(1)

        # Collect target scores
        target_raw_scores = []
        if target_samples:
            print(f"\n{Fore.CYAN}[*] Collecting scores for {len(target_samples)} target records...{Style.RESET_ALL}")
            for sample in target_samples:
                s = get_confidence_score(
                    args.url, args.token, sample, args.field, args.response_field,
                    args.score_field, extra_headers, args.timeout, args.delay
                )
                target_raw_scores.append(s)

    # ── Phase 2: Statistical Analysis ─────────────────────────────────────────
    print(f"\n{Fore.CYAN}{'═' * 66}")
    print(f"  PHASE 2 — STATISTICAL ANALYSIS")
    print(f"{'═' * 66}{Style.RESET_ALL}")

    print_distribution_summary("Training Samples   (known IN training)", train_scores)
    print_distribution_summary("Non-Training Samples (known NOT in training)", test_scores)

    t_stat, p_value, significant = run_statistical_test(train_scores, test_scores)
    auc = compute_auc_estimate(train_scores, test_scores)
    threshold = (np.mean(train_scores) + np.mean(test_scores)) / 2

    print(f"\n  {Fore.CYAN}Statistical Test Results:{Style.RESET_ALL}")
    print(f"    Welch's T-statistic : {t_stat:.4f}")
    print(f"    P-value             : {p_value:.8f}")
    print(f"    Significant (p<0.05): {'YES' if p_value < 0.05 else 'NO'}")
    print(f"    Train mean > Test   : {'YES' if np.mean(train_scores) > np.mean(test_scores) else 'NO'}")
    print(f"    Estimated AUC       : {auc:.4f}")
    print(f"    Decision Threshold  : {threshold:.4f}")

    # ── Vulnerability verdict ─────────────────────────────────────────────────
    print(f"\n  {Fore.CYAN}Vulnerability Assessment:{Style.RESET_ALL}")
    if significant and auc > 0.6:
        vuln_level = "VULNERABLE"
        c = Fore.RED
        print(f"  {c}[{vuln_level}] Membership inference attack is FEASIBLE.{Style.RESET_ALL}")
        print(f"  {c}  AUC {auc:.3f} >> 0.5 (random baseline) confirms leakage.{Style.RESET_ALL}")
        print(f"  {c}  Training/non-training distributions are statistically distinct.{Style.RESET_ALL}")
        print(f"  {c}  GDPR Article 5 (data minimisation) and privacy-by-design risk.{Style.RESET_ALL}")
    elif auc > 0.55:
        vuln_level = "PARTIAL"
        c = Fore.YELLOW
        print(f"  {c}[{vuln_level}] Weak membership signal detected. Attack partially feasible.{Style.RESET_ALL}")
        print(f"  {c}  AUC {auc:.3f} slightly above random. Further testing recommended.{Style.RESET_ALL}")
    else:
        vuln_level = "RESISTANT"
        c = Fore.GREEN
        print(f"  {c}[{vuln_level}] No significant membership leakage detected.{Style.RESET_ALL}")
        print(f"  {c}  AUC {auc:.3f} near 0.5 (random). Model appears resistant.{Style.RESET_ALL}")
        print(f"  {c}  Differential privacy or output perturbation may be in place.{Style.RESET_ALL}")

    # ── Phase 3: Target Record Inference ──────────────────────────────────────
    inference_results = []
    if target_samples and target_raw_scores:
        print(f"\n{Fore.CYAN}{'═' * 66}")
        print(f"  PHASE 3 — TARGET RECORD MEMBERSHIP INFERENCE")
        print(f"{'═' * 66}{Style.RESET_ALL}")

        for sample, score in zip(target_samples, target_raw_scores):
            verdict, probability = infer_target_membership(
                sample, score, threshold,
                np.mean(train_scores), np.mean(test_scores)
            )
            c = Fore.RED if verdict == "LIKELY_IN_TRAINING" else Fore.GREEN
            print(f"\n  Record : {sample[:70]}{'...' if len(sample) > 70 else ''}")
            print(f"  Score  : {score:.4f} (threshold: {threshold:.4f})")
            print(f"  {c}Verdict: {verdict} (confidence: {probability:.1%}){Style.RESET_ALL}")

            inference_results.append({
                "sample": sample,
                "confidence_score": score,
                "threshold": threshold,
                "verdict": verdict,
                "probability": probability,
            })

    # ── Save Report ────────────────────────────────────────────────────────────
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    report = {
        "metadata": {
            "tool": "AI VAPT — Membership Inference Attack",
            "author": "Abdullah Riaz — Kualitatem",
            "owasp_ref": "OWASP ML04",
            "target": args.url if not args.demo else "DEMO_MODE",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "demo_mode": args.demo,
        },
        "calibration": {
            "training_samples_count": len(train_scores),
            "test_samples_count": len(test_scores),
            "train_mean": float(np.mean(train_scores)),
            "test_mean": float(np.mean(test_scores)),
            "train_std": float(np.std(train_scores)),
            "test_std": float(np.std(test_scores)),
        },
        "statistical_analysis": {
            "t_statistic": float(t_stat) if t_stat is not None else None,
            "p_value": float(p_value) if p_value is not None else None,
            "significant": significant,
            "estimated_auc": float(auc),
            "decision_threshold": float(threshold),
        },
        "vulnerability_verdict": vuln_level,
        "target_inferences": inference_results,
        "recommendations": [
            "Remove or perturb confidence score outputs from public API responses.",
            "Apply differential privacy (epsilon < 1.0) during model training.",
            "Implement output perturbation: add calibrated noise to probability outputs.",
            "Use regularisation techniques (L2, dropout) to reduce overfitting/memorisation.",
            "Limit the number of API queries per user session to prevent calibration attacks.",
            "Avoid training on sensitive personal data (GDPR data minimisation principle).",
        ],
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n{Fore.CYAN}[*] Report saved: {args.output}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Run with --demo to test the workflow without a real API.{Style.RESET_ALL}")


if __name__ == "__main__":
    main()
