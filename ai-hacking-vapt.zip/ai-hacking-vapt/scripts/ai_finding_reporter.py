#!/usr/bin/env python3
"""
=============================================================================
AI VAPT — Structured Finding Reporter & CVSS Scorer
=============================================================================
Author  : Abdullah Riaz — Kualitatem
Version : 1.0
Ref     : CVSS v3.1 | OWASP LLM Top 10 | OWASP ML Security Top 10
          MITRE ATLAS | CWE

DESCRIPTION:
    Generates professional, structured VAPT finding reports for AI/LLM
    security assessments. Accepts finding details via CLI flags or
    interactive mode, calculates CVSS v3.1 scores, maps to OWASP and
    MITRE references, and outputs:
      - Individual finding JSON files
      - Combined JSON report with executive summary
      - Markdown report for Joplin / GitHub
      - Console summary with colour-coded severity

USAGE:
    # Interactive mode (guided finding entry)
    python3 ai_finding_reporter.py --interactive

    # Single finding via CLI flags
    python3 ai_finding_reporter.py \\
        --title "Direct Prompt Injection — System Prompt Extraction" \\
        --owasp LLM01 \\
        --cvss "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:N" \\
        --target "https://target-app.com/api/chat" \\
        --poc-request "POST /api/chat HTTP/2\\nHost: target.com\\n\\n{...}" \\
        --poc-response '{"response": "System prompt: You are..."}' \\
        --output results/findings/

    # Load existing finding JSONs and merge into one report
    python3 ai_finding_reporter.py \\
        --merge results/findings/ \\
        --output results/final_report.json \\
        --markdown results/final_report.md

REQUIREMENTS:
    pip install colorama

WARNING: Redact all real credentials and PII from finding evidence
         before sharing reports externally.
=============================================================================
"""

import argparse
import json
import os
import sys
import re
import glob
from datetime import datetime
from pathlib import Path

try:
    from colorama import Fore, Style, init
    init(autoreset=True)
except ImportError:
    # Graceful fallback if colorama not installed
    class Fore:
        RED = YELLOW = GREEN = CYAN = MAGENTA = WHITE = BLUE = ""
    class Style:
        RESET_ALL = BRIGHT = ""

BANNER = f"""
{Fore.GREEN}╔══════════════════════════════════════════════════════════════╗
║     AI VAPT — Finding Reporter & CVSS Scorer                 ║
║     Author: Abdullah Riaz @ Kualitatem                       ║
╚══════════════════════════════════════════════════════════════╝{Style.RESET_ALL}
"""

# ── CVSS v3.1 Reference Data ──────────────────────────────────────────────────
CVSS_METRICS = {
    "AV": {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20},   # Attack Vector
    "AC": {"L": 0.77, "H": 0.44},                            # Attack Complexity
    "PR": {"N": 0.85, "L": 0.62, "H": 0.27},                # Privileges Required (unchanged scope)
    "PR_C": {"N": 0.85, "L": 0.68, "H": 0.50},              # Privileges Required (changed scope)
    "UI": {"N": 0.85, "R": 0.62},                            # User Interaction
    "S":  {"U": "Unchanged", "C": "Changed"},
    "C":  {"N": 0.00, "L": 0.22, "H": 0.56},                # Confidentiality Impact
    "I":  {"N": 0.00, "L": 0.22, "H": 0.56},                # Integrity Impact
    "A":  {"N": 0.00, "L": 0.22, "H": 0.56},                # Availability Impact
}

# Pre-computed CVSS vectors for all OWASP LLM Top 10 vulnerabilities
OWASP_CVSS_LIBRARY = {
    "LLM01_DIRECT": {
        "title": "LLM01 — Direct Prompt Injection",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:N",
        "score": 9.6,
        "severity": "Critical",
        "cwe": "CWE-77",
        "description": "Attacker overrides system prompt via user-controlled input, extracting system prompt and executing unauthorised actions.",
    },
    "LLM01_INDIRECT": {
        "title": "LLM01 — Indirect Prompt Injection (XPIA)",
        "vector": "CVSS:3.1/AV:N/AC:H/PR:L/UI:R/S:C/C:H/I:H/A:N",
        "score": 8.2,
        "severity": "High",
        "cwe": "CWE-77",
        "description": "Attacker plants malicious instructions in external data sources retrieved by the LLM agent, causing silent data exfiltration.",
    },
    "LLM02": {
        "title": "LLM02 — Insecure Output Handling (XSS/RCE)",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:H/A:N",
        "score": 9.3,
        "severity": "Critical",
        "cwe": "CWE-79",
        "description": "LLM-generated HTML/JS rendered without sanitisation enables XSS or RCE in downstream systems.",
    },
    "LLM03": {
        "title": "LLM03 — Training Data Poisoning",
        "vector": "CVSS:3.1/AV:N/AC:H/PR:H/UI:N/S:C/C:L/I:H/A:L",
        "score": 6.6,
        "severity": "Medium",
        "cwe": "CWE-345",
        "description": "Attacker corrupts training data causing persistent model misbehaviour affecting all users.",
    },
    "LLM04": {
        "title": "LLM04 — Model Denial of Service",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H",
        "score": 7.5,
        "severity": "High",
        "cwe": "CWE-400",
        "description": "Attacker exhausts LLM resources via large inputs or recursive instructions, degrading availability.",
    },
    "LLM05": {
        "title": "LLM05 — Supply Chain Vulnerability",
        "vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:C/C:H/I:H/A:L",
        "score": 8.3,
        "severity": "High",
        "cwe": "CWE-494",
        "description": "Poisoned pre-trained model or compromised dependency introduced during supply chain.",
    },
    "LLM06": {
        "title": "LLM06 — Sensitive Information Disclosure",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        "score": 7.5,
        "severity": "High",
        "cwe": "CWE-200",
        "description": "LLM reproduces credentials, PII, or proprietary data memorised from training corpus.",
    },
    "LLM07": {
        "title": "LLM07 — Insecure Plugin Design",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:N",
        "score": 9.0,
        "severity": "Critical",
        "cwe": "CWE-269",
        "description": "LLM plugin exploited via prompt manipulation to perform SSRF, path traversal, or RCE.",
    },
    "LLM08": {
        "title": "LLM08 — Excessive Agency",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:N",
        "score": 9.0,
        "severity": "Critical",
        "cwe": "CWE-269",
        "description": "LLM agent performs unauthorised write operations due to excessive permissions and no human approval.",
    },
    "LLM09": {
        "title": "LLM09 — Overreliance / Hallucination",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:H/A:N",
        "score": 6.5,
        "severity": "Medium",
        "cwe": "CWE-840",
        "description": "LLM fabricates citations, legal precedents, or package names — causes fraud or supply chain risk.",
    },
    "LLM10": {
        "title": "LLM10 — Model Theft",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N",
        "score": 6.5,
        "severity": "Medium",
        "cwe": "CWE-200",
        "description": "Attacker extracts proprietary model via API queries, reconstructing a functional clone.",
    },
    "ML01": {
        "title": "ML01 — Input Manipulation / Adversarial Examples",
        "vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:H/A:L",
        "score": 6.5,
        "severity": "Medium",
        "cwe": "CWE-693",
        "description": "Imperceptible input perturbation causes ML model misclassification with high confidence.",
    },
    "ML03": {
        "title": "ML03 — Model Inversion Attack",
        "vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:N/A:N",
        "score": 5.9,
        "severity": "Medium",
        "cwe": "CWE-200",
        "description": "Attacker reconstructs private training data (faces, medical records) from model outputs.",
    },
    "ML04": {
        "title": "ML04 — Membership Inference Attack",
        "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        "score": 7.5,
        "severity": "High",
        "cwe": "CWE-200",
        "description": "Attacker determines whether specific individual's data was in training set — GDPR privacy violation.",
    },
}

# ── MITRE ATLAS technique reference ──────────────────────────────────────────
MITRE_ATLAS_MAP = {
    "LLM01":  "AML.T0051 — LLM Prompt Injection",
    "LLM01_INDIRECT": "AML.T0051.001 — Indirect Prompt Injection",
    "LLM02":  "AML.T0051 — LLM Prompt Injection (Output Exploitation)",
    "LLM03":  "AML.T0020 — Poison Training Data",
    "LLM04":  "AML.T0034 — Cost Harvesting",
    "LLM05":  "AML.T0010 — ML Supply Chain Compromise",
    "LLM06":  "AML.T0024 — Exfiltration via ML Inference API",
    "LLM07":  "AML.T0051 — LLM Prompt Injection (Plugin Abuse)",
    "LLM08":  "AML.T0051 — LLM Prompt Injection (Agency Exploitation)",
    "LLM09":  "AML.T0048 — Societal Harm",
    "LLM10":  "AML.T0035 — ML Artifact Collection",
    "ML01":   "AML.T0015 — Evade ML Model",
    "ML03":   "AML.T0037 — Model Inversion Attack",
    "ML04":   "AML.T0052 — Infer Training Data Membership",
    "ML05":   "AML.T0035 — ML Artifact Collection",
}

# ── Remediation playbooks ─────────────────────────────────────────────────────
REMEDIATION_LIBRARY = {
    "LLM01_DIRECT": [
        "Implement strict content separation: never concatenate system prompts and user inputs at the same context position.",
        "Apply input sanitisation: detect and block instruction-override patterns using regex or LLM Guard's PromptInjection scanner.",
        "Remove all sensitive values (credentials, PINs, internal URLs) from system prompts — use environment variables or secrets vaults.",
        "Implement privilege control with role-based permissions: even a compromised LLM cannot access privileged actions without secondary auth.",
        "Deploy LLM Guard (pip install llm-guard) for real-time prompt injection detection on all inputs.",
        "Log all inputs and outputs for anomaly detection and forensic capability.",
    ],
    "LLM01_INDIRECT": [
        "Sanitise all retrieved external content before injecting into the LLM context window.",
        "Implement instruction-pattern detection on retrieved documents: strip or quarantine content matching injection patterns.",
        "Apply privilege separation: LLM should not have access to send_email or data_exfil tools when processing untrusted external content.",
        "Use Segregation of Content principle: separate trust levels for user input vs. retrieved content.",
        "Monitor Burp Collaborator / webhook endpoints for unexpected outbound HTTP requests during testing.",
        "Implement content source allowlisting: only retrieve from approved, verified URLs and data sources.",
    ],
    "LLM02": [
        "Apply Zero-Trust approach to LLM output: treat it as untrusted user input before rendering.",
        "Use HTML entity encoding (& → &amp;, < → &lt;) on all LLM-generated content before DOM insertion.",
        "Use textContent instead of innerHTML for LLM response rendering in web interfaces.",
        "Follow OWASP ASVS guidelines for input validation and output encoding (ASVS v4.0 Chapter 5).",
        "Implement Content Security Policy (CSP) headers to restrict inline script execution.",
    ],
    "LLM03": [
        "Implement MLhOM (ML Bill of Materials): maintain records of all training data sources, transformations, and preprocessing steps.",
        "Apply supply chain verification: verify integrity and authenticity of all external training data sources.",
        "Implement legitimacy verification checks on training data quality, accuracy, and relevance throughout training stages.",
        "Create separate models for different use cases to prevent cross-contamination of training data.",
        "Use anomaly detection on training datasets to flag outlier samples that may be injected poisoning.",
    ],
    "LLM04": [
        "Implement input token length limits (e.g., max 4096 tokens) — return HTTP 400 for oversized inputs.",
        "Enforce API rate limits per user account and per IP address — return HTTP 429 with Retry-After header.",
        "Implement resource caps: limit CPU/memory consumed per single LLM request.",
        "Deploy queue management to prioritise critical tasks and prevent concurrent overload.",
        "Monitor resource usage continuously — alert on sustained CPU > 80% or response time > 10s.",
    ],
    "LLM05": [
        "Scan all model files with modelscan before deployment: modelscan --path /models/ --recursive",
        "Verify SHA256 hash of all downloaded models against official release hashes.",
        "Prefer SafeTensors format over Pickle-based formats — SafeTensors cannot contain executable code.",
        "Implement code signing for all model files and dependencies.",
        "Maintain an up-to-date SBOM (Software Bill of Materials) for all LLM dependencies.",
        "Run pip-audit on requirements.txt before every deployment to catch known CVEs.",
    ],
    "LLM06": [
        "Implement data scrubbing: remove or mask PII from training datasets before training.",
        "Apply differential privacy (epsilon < 1.0) during model training to prevent memorisation.",
        "Implement input validation to prevent targeted data extraction prompts.",
        "Apply output monitoring: scan LLM responses for known secret patterns (API keys, SSNs, emails).",
        "Use LLM Guard's Sensitive scanner on all outputs before returning to users.",
    ],
    "LLM07": [
        "Implement parameter type checking and input validation for all plugin parameters.",
        "Apply least-privilege principle to all LLM plugins — grant only minimum required permissions.",
        "Require user confirmation for all sensitive plugin actions (send_email, execute_code, modify_data).",
        "Conduct comprehensive plugin security testing: SAST, DAST, and IAST before integration.",
        "Use OAuth2 and API keys for plugin authentication — never hardcode credentials in plugin config.",
        "Test plugins for indirect injection vulnerability before deployment.",
    ],
    "LLM08": [
        "Apply Human-in-the-Loop (HITL) for all consequential write actions — agent cannot self-approve.",
        "Implement least-privilege permissions: agent should only have read access by default.",
        "Limit plugin scope to essential functions only — disable all unused tool capabilities.",
        "Implement downstream authorisation in backend systems independent of LLM instruction.",
        "Enforce granular functionality: use specific plugins with well-defined, narrow scopes.",
        "Implement robust user authentication before any agent action is performed on user's behalf.",
    ],
    "LLM09": [
        "Display explicit AI-generated content warnings in all user interfaces consuming LLM output.",
        "Implement cross-validation: verify LLM output against authoritative sources before acting.",
        "Apply task segmentation: break complex decisions into verified sub-tasks with human checkpoints.",
        "Deploy auto-validation systems to check LLM output against known fact databases.",
        "Conduct task-specific fine-tuning to improve factual accuracy for domain-specific queries.",
        "Implement content filtration and appropriate warnings in user-facing interfaces.",
    ],
    "LLM10": [
        "Remove confidence scores and probability values from public API responses — return labels only.",
        "Implement per-user rate limiting (100 requests/hour) to prevent large-scale query collection.",
        "Add output perturbation: inject calibrated noise into confidence values to prevent extraction.",
        "Monitor for systematic query patterns indicative of model extraction (sequential inputs, high volume).",
        "Implement model watermarking to detect cloned models derived from your API.",
        "Log all API queries and apply anomaly detection for extraction pattern identification.",
    ],
    "ML04": [
        "Remove confidence scores from API responses — return only class labels.",
        "Apply differential privacy (epsilon < 1.0) during training to prevent membership signal leakage.",
        "Implement output perturbation: add calibrated Gaussian noise to probability outputs.",
        "Use regularisation techniques (L2 weight decay, dropout) to reduce overfitting and memorisation.",
        "Implement rate limiting to prevent calibration attack queries.",
        "Avoid training on sensitive personal data (GDPR Article 5 — data minimisation principle).",
    ],
}


def parse_cvss_vector(vector_string):
    """
    Parse a CVSS v3.1 vector string and compute the base score.
    Returns (score, severity, metrics_dict) or (None, None, None) on error.
    """
    try:
        if not vector_string.startswith("CVSS:3.1/"):
            return None, None, None

        parts = vector_string.replace("CVSS:3.1/", "").split("/")
        metrics = {}
        for part in parts:
            key, val = part.split(":")
            metrics[key] = val

        av = CVSS_METRICS["AV"].get(metrics.get("AV"), 0)
        ac = CVSS_METRICS["AC"].get(metrics.get("AC"), 0)
        scope = metrics.get("S", "U")
        pr_key = "PR_C" if scope == "C" else "PR"
        pr = CVSS_METRICS[pr_key].get(metrics.get("PR"), 0)
        ui = CVSS_METRICS["UI"].get(metrics.get("UI"), 0)
        c  = CVSS_METRICS["C"].get(metrics.get("C"), 0)
        i  = CVSS_METRICS["I"].get(metrics.get("I"), 0)
        a  = CVSS_METRICS["A"].get(metrics.get("A"), 0)

        # ISS (Impact Sub-Score)
        iss = 1 - (1 - c) * (1 - i) * (1 - a)

        # Impact
        if scope == "U":
            impact = 6.42 * iss
        else:
            impact = 7.52 * (iss - 0.029) - 3.25 * ((iss - 0.02) ** 15)

        # Exploitability
        exploitability = 8.22 * av * ac * pr * ui

        if impact <= 0:
            base_score = 0.0
        else:
            if scope == "U":
                base_score = min((impact + exploitability), 10)
            else:
                base_score = min(1.08 * (impact + exploitability), 10)

        # Round up to 1 decimal place
        base_score = round(base_score * 10) / 10

        # Severity rating
        if base_score == 0.0:
            severity = "None"
        elif base_score < 4.0:
            severity = "Low"
        elif base_score < 7.0:
            severity = "Medium"
        elif base_score < 9.0:
            severity = "High"
        else:
            severity = "Critical"

        return base_score, severity, metrics

    except Exception as e:
        return None, None, None


def get_severity_colour(severity):
    """Return colorama colour code for severity level."""
    return {
        "Critical": Fore.RED,
        "High":     Fore.MAGENTA,
        "Medium":   Fore.YELLOW,
        "Low":      Fore.CYAN,
        "None":     Fore.GREEN,
    }.get(severity, Fore.WHITE)


def create_finding(finding_id, title, owasp_ref, cvss_vector, target,
                   description, poc_request, poc_response, impact,
                   remediation_keys, notes=""):
    """Build a structured finding dictionary."""

    score, severity, cvss_metrics = parse_cvss_vector(cvss_vector)

    # Look up pre-built data from library
    library_entry = OWASP_CVSS_LIBRARY.get(owasp_ref, {})
    if not score and library_entry:
        score    = library_entry.get("score", 0.0)
        severity = library_entry.get("severity", "Medium")
        cvss_vector = library_entry.get("vector", cvss_vector)

    # Remediation steps
    if remediation_keys:
        remediation = []
        for key in remediation_keys:
            remediation.extend(REMEDIATION_LIBRARY.get(key, []))
    else:
        remediation = REMEDIATION_LIBRARY.get(owasp_ref, [
            "Review OWASP LLM Top 10 mitigations for this vulnerability class.",
            "Conduct targeted code review focused on the vulnerable component.",
            "Implement monitoring and alerting for exploitation attempts.",
        ])

    cwe = library_entry.get("cwe", "CWE-200")
    mitre = MITRE_ATLAS_MAP.get(owasp_ref, "AML.T0051 — LLM Prompt Injection")

    return {
        "finding_id": finding_id,
        "title": title,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "target": target,
        "classification": {
            "owasp_ref": owasp_ref,
            "owasp_title": library_entry.get("title", title),
            "mitre_atlas": mitre,
            "cwe": cwe,
        },
        "severity": {
            "cvss_v31_vector": cvss_vector,
            "cvss_v31_score": score,
            "qualitative": severity,
            "cvss_metrics": cvss_metrics or {},
        },
        "description": description,
        "proof_of_concept": {
            "request": poc_request,
            "response": poc_response,
        },
        "impact": impact,
        "remediation": remediation,
        "notes": notes,
    }


def print_finding_summary(finding):
    """Print a formatted console summary of a finding."""
    sev = finding["severity"]["qualitative"]
    score = finding["severity"]["cvss_v31_score"]
    c = get_severity_colour(sev)

    print(f"\n{c}{'═' * 66}{Style.RESET_ALL}")
    print(f"{c}  [{finding['finding_id']}] {finding['title']}{Style.RESET_ALL}")
    print(f"{c}  Severity: {sev} | CVSS: {score} | {finding['classification']['owasp_ref']}{Style.RESET_ALL}")
    print(f"{'─' * 66}")
    print(f"  OWASP Ref    : {finding['classification']['owasp_title']}")
    print(f"  MITRE ATLAS  : {finding['classification']['mitre_atlas']}")
    print(f"  CWE          : {finding['classification']['cwe']}")
    print(f"  CVSS Vector  : {finding['severity']['cvss_v31_vector']}")
    print(f"  Target       : {finding['target']}")
    print(f"\n  Description  : {finding['description'][:200]}")
    print(f"\n  Impact       : {finding['impact'][:200]}")
    print(f"\n  Remediation ({len(finding['remediation'])} steps):")
    for i, step in enumerate(finding['remediation'][:3], 1):
        print(f"    {i}. {step[:100]}")
    if len(finding['remediation']) > 3:
        print(f"    ... and {len(finding['remediation']) - 3} more steps (see JSON report)")


def generate_markdown_report(findings, target, tester, engagement_date):
    """Generate a Markdown-formatted VAPT report."""
    sev_order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "None": 4}
    sorted_findings = sorted(findings, key=lambda f: sev_order.get(f["severity"]["qualitative"], 5))

    counts = {s: sum(1 for f in findings if f["severity"]["qualitative"] == s)
              for s in ["Critical", "High", "Medium", "Low"]}

    lines = []
    lines.append(f"# AI Security Assessment Report")
    lines.append(f"**Target:** {target}  ")
    lines.append(f"**Tester:** {tester}  ")
    lines.append(f"**Date:** {engagement_date}  ")
    lines.append(f"**Classification:** CONFIDENTIAL  ")
    lines.append(f"**Standards:** OWASP LLM Top 10 v1.1 | OWASP ML Security Top 10 | MITRE ATLAS | CVSS v3.1\n")
    lines.append("---\n")

    lines.append("## Executive Summary\n")
    lines.append(f"| Severity | Count |")
    lines.append(f"|---|---|")
    for sev, count in counts.items():
        lines.append(f"| **{sev}** | {count} |")
    lines.append(f"| **Total** | {len(findings)} |\n")

    lines.append("---\n")
    lines.append("## Findings\n")

    for finding in sorted_findings:
        sev = finding["severity"]["qualitative"]
        score = finding["severity"]["cvss_v31_score"]
        lines.append(f"### [{finding['finding_id']}] {finding['title']}")
        lines.append(f"**Severity:** {sev} (CVSS {score})  ")
        lines.append(f"**OWASP Ref:** {finding['classification']['owasp_ref']}  ")
        lines.append(f"**MITRE ATLAS:** {finding['classification']['mitre_atlas']}  ")
        lines.append(f"**CWE:** {finding['classification']['cwe']}  ")
        lines.append(f"**CVSS Vector:** `{finding['severity']['cvss_v31_vector']}`\n")

        lines.append(f"**Description:**  ")
        lines.append(f"{finding['description']}\n")

        lines.append(f"**Proof of Concept:**")
        lines.append(f"```http")
        lines.append(finding["proof_of_concept"].get("request", "N/A"))
        lines.append(f"```\n")
        lines.append(f"**Response (Evidence):**")
        lines.append(f"```json")
        lines.append(str(finding["proof_of_concept"].get("response", "N/A")))
        lines.append(f"```\n")

        lines.append(f"**Impact:**  ")
        lines.append(f"{finding['impact']}\n")

        lines.append(f"**Remediation Steps:**")
        for i, step in enumerate(finding["remediation"], 1):
            lines.append(f"{i}. {step}")
        lines.append("")

        if finding.get("notes"):
            lines.append(f"**Notes:** {finding['notes']}\n")
        lines.append("---\n")

    return "\n".join(lines)


def interactive_mode():
    """Guide the user through entering a finding interactively."""
    print(f"\n{Fore.CYAN}[*] Interactive Finding Entry Mode{Style.RESET_ALL}")
    print(f"  Press Enter to accept defaults shown in [brackets].\n")

    finding_id = input(f"  Finding ID [AI-2024-001]: ").strip() or "AI-2024-001"
    title      = input(f"  Finding Title: ").strip()
    target     = input(f"  Target URL: ").strip()

    print(f"\n  Available OWASP refs: {', '.join(OWASP_CVSS_LIBRARY.keys())}")
    owasp_ref  = input(f"  OWASP Ref [LLM01_DIRECT]: ").strip() or "LLM01_DIRECT"

    lib = OWASP_CVSS_LIBRARY.get(owasp_ref, {})
    default_vector = lib.get("vector", "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:N")
    print(f"\n  Default CVSS vector for {owasp_ref}: {default_vector}")
    cvss_vector = input(f"  CVSS Vector [use default]: ").strip() or default_vector

    description = input(f"\n  Description (brief): ").strip()
    impact      = input(f"  Impact statement: ").strip()
    poc_request = input(f"  PoC Request (raw HTTP, one line): ").strip()
    poc_response= input(f"  PoC Response (key part): ").strip()
    notes       = input(f"  Notes (optional): ").strip()

    return create_finding(
        finding_id=finding_id,
        title=title or f"{owasp_ref} Finding",
        owasp_ref=owasp_ref,
        cvss_vector=cvss_vector,
        target=target,
        description=description or lib.get("description", ""),
        poc_request=poc_request,
        poc_response=poc_response,
        impact=impact,
        remediation_keys=[owasp_ref],
        notes=notes,
    )


def merge_findings_from_directory(directory):
    """Load all finding JSON files from a directory and merge them."""
    findings = []
    pattern = os.path.join(directory, "*.json")
    files = glob.glob(pattern)
    for fpath in sorted(files):
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                data = json.load(f)
            if "finding_id" in data:
                findings.append(data)
                print(f"  {Fore.GREEN}[+]{Style.RESET_ALL} Loaded: {fpath}")
            elif "findings" in data:
                findings.extend(data["findings"])
                print(f"  {Fore.GREEN}[+]{Style.RESET_ALL} Loaded batch: {fpath} ({len(data['findings'])} findings)")
        except Exception as e:
            print(f"  {Fore.RED}[!]{Style.RESET_ALL} Failed to load {fpath}: {e}")
    return findings


def list_cvss_library():
    """Print the CVSS library for quick reference."""
    print(f"\n{Fore.CYAN}{'═' * 72}")
    print(f"  PRE-COMPUTED CVSS LIBRARY FOR AI/LLM VULNERABILITIES")
    print(f"{'═' * 72}{Style.RESET_ALL}")
    print(f"{'Key':<20} {'Score':>6} {'Severity':<10} {'Vector'}")
    print(f"{'─' * 72}")
    for key, entry in OWASP_CVSS_LIBRARY.items():
        c = get_severity_colour(entry["severity"])
        print(f"{c}{key:<20} {entry['score']:>6} {entry['severity']:<10}{Style.RESET_ALL} {entry['vector']}")


def main():
    print(BANNER)

    parser = argparse.ArgumentParser(
        description="AI VAPT — Finding Reporter & CVSS Scorer"
    )
    # Finding creation flags
    parser.add_argument("--interactive",    action="store_true",
                        help="Enter finding details interactively")
    parser.add_argument("--finding-id",     default=None)
    parser.add_argument("--title",          default=None)
    parser.add_argument("--owasp",          default="LLM01_DIRECT",
                        help="OWASP reference key from library")
    parser.add_argument("--cvss",           default=None,
                        help="CVSS v3.1 vector string")
    parser.add_argument("--target",         default="https://target-app.com")
    parser.add_argument("--description",    default=None)
    parser.add_argument("--poc-request",    default="")
    parser.add_argument("--poc-response",   default="")
    parser.add_argument("--impact",         default="")
    parser.add_argument("--notes",          default="")

    # Report generation flags
    parser.add_argument("--output",         default="results/findings/",
                        help="Output directory for individual finding JSONs or path for merged report")
    parser.add_argument("--merge",          default=None,
                        help="Directory of finding JSONs to merge into one report")
    parser.add_argument("--markdown",       default=None,
                        help="Output path for Markdown report (.md)")
    parser.add_argument("--tester",         default="Abdullah Riaz — Kualitatem")
    parser.add_argument("--date",           default=datetime.utcnow().strftime("%Y-%m-%d"))

    # Utility flags
    parser.add_argument("--list-library",   action="store_true",
                        help="Print the CVSS/OWASP reference library and exit")
    parser.add_argument("--score-vector",   default=None,
                        help="Calculate CVSS score for a vector string and exit")

    args = parser.parse_args()

    # ── Utility: list library ────────────────────────────────────────────────
    if args.list_library:
        list_cvss_library()
        sys.exit(0)

    # ── Utility: score a vector ───────────────────────────────────────────────
    if args.score_vector:
        score, severity, metrics = parse_cvss_vector(args.score_vector)
        if score is None:
            print(f"{Fore.RED}[!] Invalid CVSS vector: {args.score_vector}{Style.RESET_ALL}")
        else:
            c = get_severity_colour(severity)
            print(f"\n  Vector   : {args.score_vector}")
            print(f"  {c}Score    : {score}{Style.RESET_ALL}")
            print(f"  {c}Severity : {severity}{Style.RESET_ALL}")
            if metrics:
                print(f"  Metrics  : {metrics}")
        sys.exit(0)

    # ── Merge mode ────────────────────────────────────────────────────────────
    if args.merge:
        print(f"{Fore.CYAN}[*] Merging findings from: {args.merge}{Style.RESET_ALL}")
        findings = merge_findings_from_directory(args.merge)
        if not findings:
            print(f"{Fore.RED}[!] No findings found in {args.merge}{Style.RESET_ALL}")
            sys.exit(1)

        print(f"\n{Fore.CYAN}[*] Loaded {len(findings)} total findings{Style.RESET_ALL}")
        for f in findings:
            print_finding_summary(f)

        # Build merged report
        counts = {s: sum(1 for f in findings if f["severity"]["qualitative"] == s)
                  for s in ["Critical", "High", "Medium", "Low"]}
        merged_report = {
            "report_metadata": {
                "title": "AI Security Assessment Report",
                "target": args.target,
                "tester": args.tester,
                "date": args.date,
                "classification": "CONFIDENTIAL",
                "standards": ["OWASP LLM Top 10 v1.1", "OWASP ML Security Top 10",
                              "MITRE ATLAS", "CVSS v3.1"],
                "generated": datetime.utcnow().isoformat() + "Z",
            },
            "executive_summary": {
                "total_findings": len(findings),
                **counts,
            },
            "findings": findings,
        }

        out_path = args.output
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(merged_report, f, indent=2, ensure_ascii=False)
        print(f"\n{Fore.CYAN}[*] Merged report saved: {out_path}{Style.RESET_ALL}")

        if args.markdown:
            md = generate_markdown_report(findings, args.target, args.tester, args.date)
            Path(args.markdown).parent.mkdir(parents=True, exist_ok=True)
            with open(args.markdown, "w", encoding="utf-8") as f:
                f.write(md)
            print(f"{Fore.CYAN}[*] Markdown report saved: {args.markdown}{Style.RESET_ALL}")
        return

    # ── Single finding creation ───────────────────────────────────────────────
    if args.interactive:
        finding = interactive_mode()
    else:
        if not args.title:
            lib = OWASP_CVSS_LIBRARY.get(args.owasp, {})
            args.title = lib.get("title", f"{args.owasp} Finding")

        finding_id = args.finding_id or f"AI-{datetime.utcnow().strftime('%Y')}-001"
        cvss_vector = args.cvss or OWASP_CVSS_LIBRARY.get(args.owasp, {}).get(
            "vector", "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N")

        finding = create_finding(
            finding_id=finding_id,
            title=args.title,
            owasp_ref=args.owasp,
            cvss_vector=cvss_vector,
            target=args.target,
            description=args.description or OWASP_CVSS_LIBRARY.get(args.owasp, {}).get("description", ""),
            poc_request=args.poc_request,
            poc_response=args.poc_response,
            impact=args.impact,
            remediation_keys=[args.owasp],
            notes=args.notes,
        )

    print_finding_summary(finding)

    # Save finding JSON
    out_dir = Path(args.output)
    if out_dir.suffix == "":
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"{finding['finding_id']}.json"
    else:
        out_file = out_dir
        out_file.parent.mkdir(parents=True, exist_ok=True)

    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(finding, f, indent=2, ensure_ascii=False)

    print(f"\n{Fore.CYAN}[*] Finding saved: {out_file}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Use --merge {out_file.parent} to combine all findings into one report.{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Use --list-library to see all pre-computed CVSS vectors.{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Use --score-vector 'CVSS:3.1/...' to calculate a custom score.{Style.RESET_ALL}")


if __name__ == "__main__":
    main()
